import { Link, useNavigate } from "react-router-dom";

const Navbar = ({ onLogout }) => {
  const navigate = useNavigate();

  const handleLogout = () => {
    onLogout();
    navigate("/");
  };

  return (
    <nav 
      className="navbar navbar-expand-lg navbar-dark mb-4"
      style={{
        background: "linear-gradient(135deg, #2c3e50 0%, #34495e 100%)",
        boxShadow: "0 4px 20px rgba(0, 0, 0, 0.1)"
      }}
    >
      <div className="container-fluid">
        <Link 
          className="navbar-brand fw-bold" 
          to="/dashboard"
          style={{ fontSize: "1.5rem" }}
        >
          <i className="fas fa-weight me-2"></i>
          Weighbridge Pro
        </Link>
        <button 
          className="navbar-toggler" 
          type="button" 
          data-bs-toggle="collapse" 
          data-bs-target="#navbarNav"
          style={{ border: "none" }}
        >
          <span className="navbar-toggler-icon"></span>
        </button>
        <div className="collapse navbar-collapse" id="navbarNav">
          <ul className="navbar-nav me-auto">
            <li className="nav-item">
              <Link 
                className="nav-link fw-semibold px-3" 
                to="/dashboard"
                style={{ 
                  borderRadius: "8px",
                  transition: "all 0.3s ease"
                }}
                onMouseOver={(e) => {
                  e.target.style.backgroundColor = "rgba(255, 255, 255, 0.1)";
                }}
                onMouseOut={(e) => {
                  e.target.style.backgroundColor = "transparent";
                }}
              >
                <i className="fas fa-tachometer-alt me-2"></i>Dashboard
              </Link>
            </li>
            <li className="nav-item">
              <Link 
                className="nav-link fw-semibold px-3" 
                to="/records"
                style={{ 
                  borderRadius: "8px",
                  transition: "all 0.3s ease"
                }}
                onMouseOver={(e) => {
                  e.target.style.backgroundColor = "rgba(255, 255, 255, 0.1)";
                }}
                onMouseOut={(e) => {
                  e.target.style.backgroundColor = "transparent";
                }}
              >
                <i className="fas fa-table me-2"></i>Records
              </Link>
            </li>
          </ul>
          <button 
            className="btn fw-bold"
            style={{
              background: "linear-gradient(135deg, #e74c3c 0%, #c0392b 100%)",
              color: "white",
              border: "none",
              borderRadius: "8px",
              padding: "8px 20px",
              transition: "all 0.3s ease"
            }}
            onClick={handleLogout}
            onMouseOver={(e) => {
              e.target.style.transform = "translateY(-1px)";
              e.target.style.boxShadow = "0 4px 15px rgba(231, 76, 60, 0.3)";
            }}
            onMouseOut={(e) => {
              e.target.style.transform = "translateY(0)";
              e.target.style.boxShadow = "none";
            }}
          >
            <i className="fas fa-sign-out-alt me-2"></i>Logout
          </button>
        </div>
      </div>
    </nav>
  );
};

export default Navbar;