import React from "react";

const PrintModal = ({ show, record, slipType, onClose }) => {
  if (!show || !record) return null; // Completely unmount when hidden

  const handlePrint = () => {
    const win = window.open("", "", "width=300,height=500");
    win.document.write(`
      <!DOCTYPE html>
      <html>
      <head>
        <title>Weighbridge Slip</title>
        <style>
          @page {
            margin: 5mm;
            size: 80mm 200mm;
          }
          body {
            font-family: 'Arial', sans-serif;
            margin: 0;
            padding: 0;
            font-size: 10px;
            line-height: 1.2;
            color: #000;
          }
          .slip-container {
            width: 70mm;
            margin: 0 auto;
            border: 1px solid #000;
            padding: 8px;
            background: #fff;
          }
          .header {
            text-align: center;
            border-bottom: 1px solid #000;
            padding-bottom: 5px;
            margin-bottom: 8px;
          }
          .company-name {
            font-size: 12px;
            font-weight: bold;
            color: #000;
            margin: 2px 0;
          }
          .company-details {
            font-size: 8px;
            color: #000;
            margin: 1px 0;
          }
          .slip-title {
            font-size: 10px;
            font-weight: bold;
            color: #000;
            margin: 5px 0;
            text-transform: uppercase;
          }
          .content-section {
            margin: 5px 0;
          }
          .info-row {
            display: flex;
            justify-content: space-between;
            margin: 3px 0;
            padding: 1px 0;
            border-bottom: 1px dotted #999;
            font-size: 9px;
          }
          .info-label {
            font-weight: bold;
            color: #000;
          }
          .info-value {
            color: #000;
          }
          .weight-section {
            background: #fff;
            padding: 5px;
            margin: 5px 0;
            border: 1px solid #000;
          }
          .weight-row {
            display: flex;
            justify-content: space-between;
            margin: 2px 0;
            font-weight: bold;
            font-size: 12px;
          }
          .net-weight {
            background: #fff;
            color: #000;
            padding: 3px;
            border: 1px solid #000;
            font-size: 13px;
          }
          .footer {
            border-top: 1px solid #000;
            padding-top: 5px;
            margin-top: 10px;
            text-align: center;
          }
          .warning {
            background: #fff;
            border: 1px solid #000;
            padding: 4px;
            font-size: 8px;
            color: #000;
            font-weight: bold;
            margin: 5px 0;
            text-align: center;
          }
          .signature-section {
            display: flex;
            justify-content: space-between;
            margin-top: 10px;
            font-size: 8px;
          }
          .signature-box {
            text-align: center;
            width: 45%;
          }
          .signature-line {
            border-top: 1px solid #000;
            margin-top: 15px;
            padding-top: 2px;
          }
          hr {
            border: 0;
            height: 1px;
            background: #000;
            margin: 5px 0;
          }
        </style>
      </head>
      <body>
        <div class="slip-container">
          <!-- Header -->
          <div class="header">
            <div class="company-name">AWAMI COMPUTERIZED KANTA</div>
            <div class="company-details">Miro Khan Road, Larkana</div>
            <div class="company-details">Phone: 03420721023</div>
            <div class="slip-title">${
              slipType === "first"
                ? "First Weight Slip"
                : slipType === "second"
                  ? "Second Weight Slip"
                  : "Final Weight Slip"
            }</div>
          </div>

          <!-- Content -->
          <div class="content-section">
            <div class="info-row">
              <span class="info-label">Vehicle Number:</span>
              <span class="info-value">${record.vehicle_number}</span>
            </div>
            <div class="info-row">
              <span class="info-label">Product:</span>
              <span class="info-value">${record.product}</span>
            </div>
            <div class="info-row">
              <span class="info-label">Driver Name:</span>
              <span class="info-value">${record.driver}</span>
            </div>
          </div>

          <!-- Weight Section -->
          <div class="weight-section">
            ${
              slipType !== "final"
                ? `
              <div class="weight-row">
                <span>First Weight:</span>
                <span>${Number(record.first_weight).toFixed(2)} Kg</span>
              </div>
              <div class="info-row">
                <span class="info-label">First Weight Time:</span>
                <span class="info-value">${record.first_weight_time}</span>
              </div>
            `
                : ""
            }
            
            ${
              slipType !== "first" && record.second_weight
                ? `
              <div class="weight-row">
                <span>${slipType === "final" ? "Empty Weight:" : "Second Weight:"}</span>
                <span>${Number(record.second_weight).toFixed(2)} Kg</span>
              </div>
              ${
                slipType !== "final"
                  ? `
                <div class="info-row">
                  <span class="info-label">Second Weight Time:</span>
                  <span class="info-value">${record.second_weight_time}</span>
                </div>
              `
                  : ""
              }
            `
                : ""
            }

            ${
              slipType === "final" && record.second_weight
                ? `
              <div class="weight-row">
                <span>Current Weight:</span>
                <span>${Number(record.first_weight).toFixed(2)} Kg</span>
              </div>
              <div class="info-row">
                <span class="info-label">Current Weight Time:</span>
                <span class="info-value">${record.first_weight_time}</span>
              </div>
            `
                : ""
            }

            ${
              slipType !== "first" && record.net_weight
                ? `
              <div class="net-weight">
                <div class="weight-row">
                  <span>Net Weight:</span>
                  <span>${Number(record.net_weight).toFixed(2)} Kg</span>
                </div>
                <div class="weight-row">
                  <span>Munds:</span>
                  <span>${Math.floor(record.net_weight / 40)} Munds ${Math.round(record.net_weight - Math.floor(record.net_weight / 40) * 40)} Kg</span>
                </div>
              </div>
            `
                : ""
            }

            <div class="info-row" style="border-bottom: 2px solid #333; font-size: 16px;">
              <span class="info-label">Total Price:</span>
              <span class="info-value" style="font-weight: bold; color: #2e7d32;">${record.total_price} PKR</span>
            </div>
          </div>

          <!-- Warning Notice -->
          <div class="warning">
            ⚠️ IMPORTANT: Please check weight accuracy before leaving the premises. No changes will be accepted after departure.
          </div>

          <!-- Signature Section -->
          <div class="signature-section">
            <div class="signature-box">
              <div class="signature-line">Operator Signature</div>
            </div>
            <div class="signature-box">
              <div class="signature-line">Driver Signature</div>
            </div>
          </div>

          <!-- Footer -->
          <div class="footer">
            <div style="font-size: 10px; color: #666;">
              Date: ${new Date().toLocaleDateString()} | Time: ${new Date().toLocaleTimeString()}
            </div>
            <div style="font-size: 9px; color: #999; margin-top: 5px;">
              This is a computer-generated slip. Please retain for your records.
            </div>
          </div>
        </div>
      </body>
      </html>
    `);
    win.document.close();
    win.print();
  };

  return (
    <>
      {/* Backdrop */}
      <div className="modal-backdrop fade show" style={{ zIndex: 1040 }}></div>

      {/* Modal */}
      <div
        className="modal d-block fade show"
        tabIndex="-1"
        style={{ zIndex: 1050 }}
      >
        <div className="modal-dialog">
          <div className="modal-content">
            <div className="modal-header">
              <h5 className="modal-title">Weighbridge Slip</h5>
              <button
                type="button"
                className="btn-close"
                onClick={onClose}
              ></button>
            </div>
            <div className="modal-body" id="print-area">
              <div className="text-center mb-3">
                <img src="/logo512.png" alt="Logo" style={{ height: "50px" }} />
                <h4>Awami Computerized Kanta</h4>
                <p>Miro Khan Road, Larkana | Phone: 03420721023</p>
                <hr />
              </div>
              <h4 className="text-center">
                {slipType === "first"
                  ? "First Weight Slip"
                  : slipType === "second"
                    ? "Second Weight Slip"
                    : "Final Weight Slip"}
              </h4>
              <hr />

              {/* ✅ Common Info */}
              <p>
                <strong>Vehicle Number:</strong> {record.vehicle_number}
              </p>
              <p>
                <strong>Product:</strong> {record.product}
              </p>
              <p>
                <strong>Driver:</strong> {record.driver}
              </p>

              {/* ✅ First Slip Details */}
              {slipType !== "final" && (
                <>
                  <p>
                    <strong>First Weight:</strong>{" "}
                    {Number(record.first_weight).toFixed(2)} Kg
                  </p>

                  <p>
                    <strong>First Weight Time:</strong>{" "}
                    {record.first_weight_time}
                  </p>
                </>
              )}
              {/* ✅ Second Slip Details */}
              {slipType !== "first" && record.second_weight && (
                <>
                  <p>
                    <strong>
                      {slipType === "final"
                        ? "Empty Weight:"
                        : "Second Weight:"}
                    </strong>{" "}
                    {Number(record.second_weight).toFixed(2)} Kg
                  </p>
                  {slipType !== "final" && (
                    <p>
                      <strong>Second Weight Time:</strong>{" "}
                      {record.second_weight_time}
                    </p>
                  )}
                </>
              )}

              {/* ✅ Final Slip Extra Details */}
              {slipType === "final" && record.second_weight && (
                <>
                  <p>
                    <strong>Current Weight:</strong>{" "}
                    {Number(record.first_weight).toFixed(2)} kg
                  </p>
                  <p>
                    <strong>Current Weight Time:</strong>{" "}
                    {record.first_weight_time}
                  </p>
                </>
              )}

              {/* ✅ Net Weight & Munds */}
              {slipType !== "first" && record.net_weight && (
                <p>
                  <strong>Net Weight:</strong>{" "}
                  {Number(record.net_weight).toFixed(2)} kg &nbsp;
                  <strong>Munds:</strong> {Math.floor(record.net_weight / 40)}{" "}
                  Munds{" "}
                  {Math.round(
                    record.net_weight - Math.floor(record.net_weight / 40) * 40,
                  )}{" "}
                  Kg
                </p>
              )}

              {/* ✅ Price Calculation */}
              <p>
                <strong>Price:</strong> {record.total_price} PKRsss
              </p>
            </div>
            <div className="modal-footer">
              <button className="btn btn-primary" onClick={handlePrint}>
                Print
              </button>
              <button className="btn btn-secondary" onClick={onClose}>
                Close
              </button>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default PrintModal;
