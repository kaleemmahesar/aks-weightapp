
import React, { useEffect } from "react";
import { useFormik } from "formik";
import * as Yup from "yup";
import Select from "react-select";
import axios from "axios";
import "../styles/WeightForms.css";
import { FaBalanceScale } from "react-icons/fa";

export default function SecondWeightForm({ records, liveWeight, vehiclePrices, onSuccess }) {
  const options = records
    .filter((r) => r.second_weight === null)
    .map((r) => ({
      value: r.id,
      label: `${r.vehicle_number} | Serial No: ${r.id}`,
    }));

  const customSelectStyles = {
    control: (provided, state) => ({
      ...provided,
      borderRadius: '10px',
      border: '2px solid #e3e6f0',
      fontSize: '16px',
      minHeight: '58px',
      boxShadow: state.isFocused ? '0 0 0 0.2rem rgba(102, 126, 234, 0.25)' : 'none',
      borderColor: state.isFocused ? '#667eea' : '#e3e6f0',
      '&:hover': {
        borderColor: '#667eea'
      }
    }),
    option: (provided, state) => ({
      ...provided,
      backgroundColor: state.isSelected ? '#667eea' : state.isFocused ? '#f8f9fc' : 'white',
      color: state.isSelected ? 'white' : '#495057'
    })
  };

  const formik = useFormik({
    initialValues: {
      selectedVehicle: null,
      secondWeight: liveWeight || "",
    },
    validationSchema: Yup.object({
      selectedVehicle: Yup.object().required("Select a vehicle"),
      secondWeight: Yup.number()
        .typeError("Weight must be a number")
        .required("Second weight is required")
        .positive("Weight must be positive"),
    }),
    onSubmit: async (values, { resetForm }) => {
      const recordId = values.selectedVehicle.value;
      const record = records.find((r) => r.id === recordId);
      if (!record) return alert("Record not found");

      const firstWeight = parseFloat(record.first_weight);
      const secondWeight = parseFloat(values.secondWeight);
      const netWeight = firstWeight - secondWeight;

      const totalPrice =
        parseFloat(record.total_price) || vehiclePrices[record.vehicle_type] || 0;

      try {
        const response = await axios.post(
          "http://localhost/weightscale/index.php?action=saveSecondWeight",
          {
            id: recordId,
            secondWeight,
            netWeight,
            totalPrice,
          },
          { headers: { "Content-Type": "application/json" } }
        );

        if (response.data.status === "success") {
          console.log("✅ Second weight saved:", response.data);
          const formatTo12Hour = (dateString) => {
            const date = new Date(dateString);
            return date.toLocaleString("en-US", {
              timeZone: "Asia/Karachi",
              month: "2-digit",
              day: "2-digit",
              year: "numeric",
              hour: "numeric",
              minute: "2-digit",
              hour12: true
            });
          };

          const updatedRecord = {
            ...record,
            second_weight: secondWeight,
            net_weight: netWeight,
            total_price: totalPrice,
            second_weight_time: formatTo12Hour(new Date()),
          };

          if (onSuccess) {
            onSuccess(updatedRecord, "second");
          }

          resetForm();
        } else {
          alert(response.data.message || "Failed to save second weight");
        }
      } catch (error) {
        console.error("Error saving second weight:", error);
        alert("Error saving second weight. Check console for details.");
      }
    },
  });

  useEffect(() => {
    formik.setFieldValue("secondWeight", liveWeight || "");
  }, [liveWeight]);

  return (
    <div className="weight-form-card">
      <div className="weight-form-header second-weight">
        <div className="weight-form-header-content">
          <div className="weight-form-icon">
            <FaBalanceScale size={30} className="text-secondary text-white" />
          </div>
          <div>
            <h4 className="weight-form-title">Second Weight Entry</h4>
            <p className="weight-form-subtitle">Record final vehicle weight measurement</p>
          </div>
        </div>
      </div>

      <div className="weight-form-body">
        <form onSubmit={formik.handleSubmit}>
          <div className="row g-4">
            <div className="col-md-6">
              <Select
                options={options}
                value={formik.values.selectedVehicle}
                onChange={(option) =>
                  formik.setFieldValue("selectedVehicle", option)
                }
                isSearchable
                styles={customSelectStyles}
                placeholder="Search and select vehicle..."
              />
              {formik.touched.selectedVehicle && formik.errors.selectedVehicle && (
                <div className="text-danger mt-2 small">{formik.errors.selectedVehicle}</div>
              )}
            </div>

            <div className="col-md-6">
              <div className="form-floating position-relative">
                <input
                  type="number"
                  name="secondWeight"
                  id="secondWeight"
                  className={`form-control live-weight-input ${
                    formik.touched.secondWeight && formik.errors.secondWeight
                      ? "is-invalid"
                      : ""
                  }`}
                  value={formik.values.secondWeight}
                  onChange={formik.handleChange}
                  onBlur={formik.handleBlur}
                  placeholder="0"
                />
                <label htmlFor="secondWeight" className="text-success fw-bold">
                  <i className="fas fa-weight me-2"></i>Live Weight (kg)
                </label>
                <span className="live-indicator"></span>
                {formik.touched.secondWeight && formik.errors.secondWeight && (
                  <div className="invalid-feedback">{formik.errors.secondWeight}</div>
                )}
              </div>
            </div>
          </div>

          <div className="row mt-4">
            <div className="col-lg-4 col-md-6 col-sm-8 mx-auto">
              <button type="submit" className="submit-button second-weight">
                <i className="fas fa-balance-scale me-2"></i>
                Save Second Weight
              </button>
            </div>
          </div>
        </form>
      </div>
    </div>
  );
}
