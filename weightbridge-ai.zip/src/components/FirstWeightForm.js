import React, { useEffect } from "react";
import { useFormik } from "formik";
import * as Yup from "yup";
import axios from "axios";
import "../styles/WeightForms.css";
import { FaBalanceScale  } from "react-icons/fa";
import notify from "./notification";
const FirstWeightForm = ({ liveWeight, vehiclePrices, onSuccess }) => {
  const [totalPrice, setTotalPrice] = React.useState(0);

  // ✅ When vehicleType changes, update price dynamically
  const handleVehicleTypeChange = (e) => {
    formik.handleChange(e);
    const selectedType = e.target.value;
    setTotalPrice(vehiclePrices[selectedType]);
  };

  const validationSchema = Yup.object({
    vehicleNumber: Yup.string().required("Vehicle number is required"),
    party: Yup.string().required("Party Name is required"),
    vehicleType: Yup.string().required("Vehicle type is required"),
    product: Yup.string().notOneOf(["Select"], "Please select a product"),
    currentWeight: Yup.number()
      .required("Weight is required")
      .min(1, "Weight must be greater than 0"),
    withDriver: Yup.boolean()
  });

  const formik = useFormik({
    initialValues: {
      vehicleNumber: "",
      party: "",
      vehicleType: "Truck",
      product: "Select",
      currentWeight: 0,
      withDriver: false
    },
    validationSchema,
    onSubmit: async (values, { resetForm }) => {
      const updatedValues = {
        ...values,
        price: totalPrice
      };

      // ✅ Prepare API payload
      const newRecord = {
        vehicle: updatedValues.vehicleNumber,
        party: updatedValues.party, 
        type: updatedValues.vehicleType,
        product: updatedValues.product,
        weight: parseFloat(updatedValues.currentWeight),
        price: updatedValues.price,
        driver: updatedValues.withDriver ? "Yes" : "No"
      };

      console.log("New Record to save:", newRecord);

      try {
        const response = await axios.post(
          "http://localhost/weightscale/index.php?action=saveFirstWeight",
          newRecord,
          { headers: { "Content-Type": "application/json" } }
        );

        if (response.data.status === "success") {
          console.log("✅ First weight saved:", response.data);

          const formatTo12Hour = (dateString) => {
            const date = new Date(dateString);
            return date.toLocaleString("en-US", {
              timeZone: "Asia/Karachi", // ✅ Force PKT
              month: "2-digit",
              day: "2-digit",
              year: "numeric",
              hour: "numeric",
              minute: "2-digit",
              hour12: true
            });
          };

          const savedRecord = {
            id: response.data.id,
            vehicle_number: response.data.vehicle,
            party_name: response.data.party,
            vehicle_type: response.data.type,
            product: response.data.product,
            first_weight: response.data.weight,
            price_per_kg: response.data.price,
            first_weight_time: formatTo12Hour(response.data.firstTime),
            driver_name: response.data.driver,
            second_weight: null,
            net_weight: null,
            total_price: response.data.price,
            second_weight_time: null
          };

          // ✅ If parent needs to update state or show modal
          if (onSuccess) {
            onSuccess(savedRecord, "first");
          }

          resetForm();
        } else {
          notify.error(response.data.message || "Failed to save record");
        }
      } catch (error) {
        console.error(error);
        notify.error("Error saving record");
      }
    }
  });

  // ✅ Update weight when liveWeight changes
  useEffect(() => {
    if (liveWeight && liveWeight > 0) {
      formik.setFieldValue("currentWeight", liveWeight);
    }
  }, [liveWeight]);

  return (
    <div className="weight-form-card">
      <div className="weight-form-header first-weight">
        <div className="weight-form-header-content">
          <div className="weight-form-icon">
                      <FaBalanceScale size={30} className="text-secondary text-white" />
                    </div>
          <div>
            <h4 className="weight-form-title">First Weight Entry</h4>
            <p className="weight-form-subtitle">Record initial vehicle weight measurement</p>
          </div>
        </div>
      </div>

      <div className="weight-form-body">
        <form onSubmit={formik.handleSubmit}>
          <div className="row g-4">
            {/* Vehicle Number */}
            <div className="col-lg-4 col-md-12">
              <div className="form-floating">
                <input
                  type="text"
                  name="vehicleNumber"
                  id="vehicleNumber"
                  className={`form-control modern-input ${
                    formik.touched.vehicleNumber && formik.errors.vehicleNumber
                      ? "is-invalid"
                      : ""
                  }`}
                  value={formik.values.vehicleNumber}
                  onChange={formik.handleChange}
                  onBlur={formik.handleBlur}
                  placeholder="Vehicle Number"
                />
                <label htmlFor="vehicleNumber" className="floating-label">
                  Vehicle Number
                </label>
                {formik.touched.vehicleNumber && formik.errors.vehicleNumber && (
                  <div className="invalid-feedback">
                    {formik.errors.vehicleNumber}
                  </div>
                )}
              </div>
            </div>

            <div className="col-lg-4 col-md-12">
              <div className="form-floating">
                <input
                  type="text"
                  name="party"
                  id="party"
                  className={`form-control modern-input ${
                    formik.touched.party && formik.errors.party
                      ? "is-invalid"
                      : ""
                  }`}
                  value={formik.values.party}
                  onChange={formik.handleChange}
                  onBlur={formik.handleBlur}
                  placeholder="Party Name"
                />
                <label htmlFor="party" className="floating-label">
                  Party Name
                </label>
                {formik.touched.party && formik.errors.party && (
                  <div className="invalid-feedback">
                    {formik.errors.party}
                  </div>
                )}
              </div>
            </div>

            {/* Vehicle Type */}
            <div className="col-lg-4 col-md-12">
              <div className="form-floating">
                <select
                  name="vehicleType"
                  id="vehicleType"
                  className={`form-select modern-select ${
                    formik.touched.vehicleType && formik.errors.vehicleType
                      ? "is-invalid"
                      : ""
                  }`}
                  value={formik.values.vehicleType}
                  onChange={handleVehicleTypeChange}
                  onBlur={formik.handleBlur}
                >
                  {Object.keys(vehiclePrices).map((type) => (
                    <option key={type} value={type}>
                      {type} — {vehiclePrices[type].toLocaleString()}
                    </option>
                  ))}
                </select>
                <label htmlFor="vehicleType" className="floating-label">
                  Vehicle Type & Price
                </label>
                {formik.touched.vehicleType && formik.errors.vehicleType && (
                  <div className="invalid-feedback">{formik.errors.vehicleType}</div>
                )}
              </div>
            </div>

            {/* Product */}
            <div className="col-lg-4 col-md-12">
              <div className="form-floating">
                <select
                  name="product"
                  id="product"
                  className={`form-select modern-select ${
                    formik.touched.product && formik.errors.product
                      ? "is-invalid"
                      : ""
                  }`}
                  value={formik.values.product}
                  onChange={formik.handleChange}
                  onBlur={formik.handleBlur}
                >
                  <option value="Select">Select Product</option>
                  <option value="Cement">Cement</option>
                  <option value="Steel">Steel</option>
                  <option value="Sand">Sand</option>
                </select>
                <label htmlFor="product" className="floating-label">
                  Product Type
                </label>
                {formik.touched.product && formik.errors.product && (
                  <div className="invalid-feedback">{formik.errors.product}</div>
                )}
              </div>
            </div>

            {/* Current Weight - Enhanced with Live indicator */}
            <div className="col-lg-4 col-md-12">
              <div className="form-floating position-relative">
                <input
                  type="number"
                  name="currentWeight"
                  id="currentWeight"
                  className={`form-control live-weight-input ${
                    formik.touched.currentWeight && formik.errors.currentWeight
                      ? "is-invalid"
                      : ""
                  }`}
                  value={formik.values.currentWeight}
                  onChange={formik.handleChange}
                  onBlur={formik.handleBlur}
                  readOnly
                  placeholder="0"
                />
                <label htmlFor="currentWeight" className="text-success fw-bold">
                  Live Weight (kg)
                </label>
                {/* Live indicator */}
                <span className="live-indicator"></span>
                {formik.touched.currentWeight && formik.errors.currentWeight && (
                  <div className="invalid-feedback">
                    {formik.errors.currentWeight}
                  </div>
                )}
              </div>
            </div>
          
                <div className="col-lg-4 col-md-12">
          {/* Driver Checkbox - Enhanced styling */}
          <div className="checkbox-container mt-0">
            <div className="form-check">
              <input
                type="checkbox"
                name="withDriver"
                id="withDriver"
                className="form-check-input modern-checkbox"
                checked={formik.values.withDriver}
                onChange={formik.handleChange}
              />
              <label className="form-check-label ms-2 fw-semibold" htmlFor="withDriver">
                
                Include Driver
              </label>
            </div>
          </div>
          </div>
                </div>
          {/* Price Display */}
          
          {/* {totalPrice > 0 && (
            <div className="price-alert alert alert-info d-flex align-items-center">
              <i className="fas fa-info-circle fa-lg me-3"></i>
              <div>
                <strong>Selected Vehicle Price: ₹{totalPrice.toLocaleString()}</strong>
                <div className="small opacity-75">This will be applied to the weight calculation</div>
              </div>
            </div>
          )} */}

          {/* Submit Button - Enhanced */}
          <div className="row mt-4">
            <div className="col-lg-4 col-md-6 col-sm-8 mx-auto">
              <button type="submit" className="submit-button">
                Save First Weight
              </button>
            </div>
          </div>
        </form>
      </div>

      
    </div>
  );
};

export default FirstWeightForm;