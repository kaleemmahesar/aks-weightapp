import React, { useEffect, useState } from "react";
import { useFormik } from "formik";
import * as Yup from "yup";
import axios from "axios";
import "../styles/WeightForms.css";
import { FaBalanceScale } from "react-icons/fa";

export default function FinalWeightForm({
  vehiclePrices,
  liveWeight,
  onSuccess,
}) {
  const [finalVehicle, setFinalVehicle] = useState("");
  const [finalVehicleType, setFinalVehicleType] = useState("Truck");
  const [finalProduct, setFinalProduct] = useState("Select");
  const [emptyWeight, setEmptyWeight] = useState("");
  const [finalWeight, setFinalWeight] = useState("");
  const [finalWithDriver, setFinalWithDriver] = useState(true);

  const getCurrentDateTime = () => {
    const now = new Date();
    const options = {
      timeZone: "Asia/Karachi",
      year: "numeric",
      month: "2-digit",
      day: "2-digit",
      hour: "2-digit",
      minute: "2-digit",
      second: "2-digit",
      hour12: false,
    };

    const formatted = new Intl.DateTimeFormat("en-CA", options).format(now);
    return formatted.replace(",", "").replace(/\//g, "-");
  };

  const formik = useFormik({
    initialValues: {
      finalVehicle,
      party: "",
      finalVehicleType,
      finalProduct,
      emptyWeight,
      finalWeight,
      finalWithDriver,
      
    },
    enableReinitialize: true,
    validationSchema: Yup.object({
      finalVehicle: Yup.string().required("Required"),
      party: Yup.string().required("Required"),
      finalVehicleType: Yup.string().required("Required"),
      finalProduct: Yup.string().required("Required"),
      emptyWeight: Yup.number()
        .typeError("Must be a number")
        .required("Required"),
      finalWeight: Yup.number()
        .typeError("Must be a number")
        .required("Required"),
    }),
    onSubmit: async (values, { resetForm }) => {
      const netWeight =
        parseFloat(values.finalWeight) - parseFloat(values.emptyWeight);
      const totalPrice = vehiclePrices[values.finalVehicleType] || 0;

      const recordData = {
        vehicle_number: values.finalVehicle,
        party: values.party, 
        vehicle_type: values.finalVehicleType,
        product: values.finalProduct,
        first_weight: values.finalWeight,
        second_weight: values.emptyWeight,
        net_weight: netWeight,
        total_price: totalPrice,
        driver_name: values.finalWithDriver ? "Yes" : "No",
        first_weight_time: getCurrentDateTime(),
        second_weight_time: getCurrentDateTime(),
        final_weight: "Yes",
      };

      try {
        const response = await axios.post(
          "http://localhost/weightscale/index.php?action=saveFinalWeight",
          recordData,
          { headers: { "Content-Type": "application/json" } },
        );

        if (response.data.status === "success") {
          console.log("✅ Final weight saved:", response.data);

          const recordedData = { id: response.data.id, ...recordData };
          if (onSuccess) onSuccess(recordedData, "final");
          resetForm();
          setFinalVehicle("");
          setFinalVehicleType("Truck");
          setFinalProduct("Select");
          setEmptyWeight("");
          setFinalWeight("");
          setFinalWithDriver(true);
        } else {
          alert(response.data.message || "Failed to save final weight");
        }
      } catch (error) {
        console.error("Error saving final weight:", error);
        alert("Error saving final weight. Check console.");
      }
    },
  });

  useEffect(() => {
    if (liveWeight) {
      formik.setFieldValue("finalWeight", liveWeight);
      setFinalWeight(liveWeight);
    }
  }, [liveWeight]);

  return (
    <div className="weight-form-card">
      <div className="weight-form-header final-weight">
        <div className="weight-form-header-content">
          <div className="weight-form-icon">
                      <FaBalanceScale size={30} className="text-secondary text-white" />
                    </div>
          <div>
            <h4 className="weight-form-title">Final Weight Entry</h4>
            <p className="weight-form-subtitle">
              Complete transaction with full weight calculation
            </p>
          </div>
        </div>
      </div>

      <div className="weight-form-body">
        <form onSubmit={formik.handleSubmit}>
          <div className="row g-4">
            <div className="col-lg-4 col-md-6">
              <div className="form-floating">
                <input
                  type="text"
                  name="finalVehicle"
                  id="finalVehicle"
                  className={`form-control modern-input ${formik.touched.finalVehicle && formik.errors.finalVehicle ? "is-invalid" : ""}`}
                  value={formik.values.finalVehicle}
                  onChange={(e) => {
                    formik.handleChange(e);
                    setFinalVehicle(e.target.value);
                  }}
                  onBlur={formik.handleBlur}
                  placeholder="Vehicle / Customer"
                />
                <label htmlFor="finalVehicle" className="floating-label">
                  Vehicle Number
                </label>
                {formik.touched.finalVehicle && formik.errors.finalVehicle && (
                  <div className="invalid-feedback">
                    {formik.errors.finalVehicle}
                  </div>
                )}
              </div>
            </div>

            <div className="col-lg-4 col-md-12">
              <div className="form-floating">
                <input
                  type="text"
                  name="party"
                  id="party"
                  className={`form-control modern-input ${
                    formik.touched.party && formik.errors.party
                      ? "is-invalid"
                      : ""
                  }`}
                  value={formik.values.party}
                  onChange={formik.handleChange}
                  onBlur={formik.handleBlur}
                  placeholder="Party Name"
                />
                <label htmlFor="party" className="floating-label">
                  Party Name
                </label>
                {formik.touched.party && formik.errors.party && (
                  <div className="invalid-feedback">
                    {formik.errors.party}
                  </div>
                )}
              </div>
            </div>

            <div className="col-lg-4 col-md-6">
              <div className="form-floating">
                <select
                  name="finalVehicleType"
                  id="finalVehicleType"
                  className={`form-select modern-select ${formik.touched.finalVehicleType && formik.errors.finalVehicleType ? "is-invalid" : ""}`}
                  value={formik.values.finalVehicleType}
                  onChange={(e) => {
                    formik.handleChange(e);
                    setFinalVehicleType(e.target.value);
                  }}
                  onBlur={formik.handleBlur}
                >
                  {Object.entries(vehiclePrices).map(([type, price], idx) => (
                    <option key={idx} value={type}>
                      {type} — {price.toLocaleString()}
                    </option>
                  ))}
                </select>
                <label htmlFor="finalVehicleType" className="floating-label">
                  Vehicle Type
                </label>
                {formik.touched.finalVehicleType &&
                  formik.errors.finalVehicleType && (
                    <div className="invalid-feedback">
                      {formik.errors.finalVehicleType}
                    </div>
                  )}
              </div>
            </div>

            <div className="col-lg-4 col-md-6">
              <div className="form-floating">
                <select
                  name="finalProduct"
                  id="finalProduct"
                  className={`form-select modern-select ${formik.touched.finalProduct && formik.errors.finalProduct ? "is-invalid" : ""}`}
                  value={formik.values.finalProduct}
                  onChange={(e) => {
                    formik.handleChange(e);
                    setFinalProduct(e.target.value);
                  }}
                  onBlur={formik.handleBlur}
                >
                  <option value="Woods">Woods</option>
                  <option value="Sand">Sand</option>
                  <option value="Chicken">Chicken</option>
                </select>
                <label htmlFor="finalProduct" className="floating-label">
                  Product
                </label>
                {formik.touched.finalProduct && formik.errors.finalProduct && (
                  <div className="invalid-feedback">
                    {formik.errors.finalProduct}
                  </div>
                )}
              </div>
            </div>

            <div className="col-lg-4 col-md-6">
              <div className="form-floating">
                <input
                  type="number"
                  name="emptyWeight"
                  id="emptyWeight"
                  className={`form-control modern-input ${formik.touched.emptyWeight && formik.errors.emptyWeight ? "is-invalid" : ""}`}
                  value={formik.values.emptyWeight}
                  onChange={(e) => {
                    formik.handleChange(e);
                    setEmptyWeight(e.target.value);
                  }}
                  onBlur={formik.handleBlur}
                  placeholder="0"
                />
                <label htmlFor="emptyWeight" className="floating-label">
                  Empty Weight (KG)
                </label>
                {formik.touched.emptyWeight && formik.errors.emptyWeight && (
                  <div className="invalid-feedback">
                    {formik.errors.emptyWeight}
                  </div>
                )}
              </div>
            </div>

            <div className="col-lg-4 col-md-6">
              <div className="form-floating position-relative">
                <input
                  type="number"
                  name="finalWeight"
                  id="finalWeight"
                  className={`form-control live-weight-input ${formik.touched.finalWeight && formik.errors.finalWeight ? "is-invalid" : ""}`}
                  value={formik.values.finalWeight}
                  onChange={(e) => {
                    formik.handleChange(e);
                    setFinalWeight(e.target.value);
                  }}
                  onBlur={formik.handleBlur}
                  placeholder="0"
                />
                <label htmlFor="finalWeight" className="text-success fw-bold">
                  Current Weight (KG)
                </label>
                <span className="live-indicator"></span>
                {formik.touched.finalWeight && formik.errors.finalWeight && (
                  <div className="invalid-feedback">
                    {formik.errors.finalWeight}
                  </div>
                )}
              </div>
            </div>

            <div className="col-lg-4 col-md-6">
              <div className="form-floating">
                <input
                  type="number"
                  id="netWeight"
                  className="form-control modern-input"
                  value={
                    formik.values.finalWeight && formik.values.emptyWeight
                      ? (
                          formik.values.finalWeight - formik.values.emptyWeight
                        ).toFixed(2)
                      : ""
                  }
                  readOnly
                  style={{ backgroundColor: "#e9ecef", fontWeight: "600" }}
                />
                <label htmlFor="netWeight" className="floating-label">
                  Net Weight (KG)
                </label>
              </div>
            </div>
          </div>

          <div className="checkbox-container">
            <div className="form-check">
              <input
                type="checkbox"
                name="finalWithDriver"
                id="finalWithDriver"
                className="form-check-input modern-checkbox"
                checked={formik.values.finalWithDriver}
                onChange={(e) => {
                  formik.setFieldValue("finalWithDriver", e.target.checked);
                  setFinalWithDriver(e.target.checked);
                }}
              />
              <label
                className="form-check-label ms-2 fw-semibold"
                htmlFor="finalWithDriver"
              >
                Include Driver in Weight
              </label>
            </div>
          </div>

          <div className="row mt-4">
            <div className="col-lg-4 col-md-6 col-sm-8 mx-auto">
              <button type="submit" className="submit-button final-weight">
                Save Final Weight
              </button>
            </div>
          </div>
        </form>
      </div>
    </div>
  );
}
