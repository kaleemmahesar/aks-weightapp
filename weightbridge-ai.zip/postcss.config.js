
module.exports = {
  plugins: {
    autoprefixer: {},
  },
}
